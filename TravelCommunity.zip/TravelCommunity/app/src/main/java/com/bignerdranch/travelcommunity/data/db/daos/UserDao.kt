package com.bignerdranch.travelcommunity.data.db.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import com.bignerdranch.travelcommunity.data.db.entity.User
import java.math.BigInteger


/*User表操作接口函数*/
@Dao
interface UserDao {
    @Query("SELECT * from user")
    fun getUsers():LiveData<List<User>>

    @Query("SELECT * from user where user.id = :userId")
    fun getUser(userId:Int):LiveData<User>

    @Query("SELECT nick_name from user Where user.id = :userId")
    fun getNickName(userId:Int):LiveData<String>

    @Query("select id from user where user.nick_name = :nickName")
    fun getUserId(nickName:String):LiveData<Int>

    //for test
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(users:List<User>)

    @Delete
    suspend fun deleteUser(userId: Int)
}

