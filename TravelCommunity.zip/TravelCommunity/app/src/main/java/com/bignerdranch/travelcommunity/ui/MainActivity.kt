package com.bignerdranch.travelcommunity.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.bignerdranch.travelcommunity.R

class MainActivity : AppCompatActivity() {
     val url = "https://upload.wikimedia.org/wikipedia/commons/5/55/Apple_orcharin_Tasmania.jpg"
    var view: ImageView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }


}
