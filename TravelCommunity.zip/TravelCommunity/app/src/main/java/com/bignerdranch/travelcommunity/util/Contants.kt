package com.bignerdranch.travelcommunity.util

const val DATABASE_NAME = "travelCommunity-db"
const val PLANT_DATA_FILENAME = ""